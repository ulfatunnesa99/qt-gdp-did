"""
Quantitative Tightening and U.S. GDP: a difference-in-differences study.

Estimates the average real-GDP-growth differential during two Federal Reserve
balance-sheet runoff episodes (QT1, 2017-2019; QT2, 2022 onward) relative to
non-QT baseline quarters, with a COVID control and Newey-West (HAC) standard
errors appropriate for serially correlated time series. Also runs an
event-study around each QT start date to inspect pre-treatment trends.

Usage:
    python src/analysis.py               # pull real FRED data and estimate
    python src/analysis.py --synthetic   # run on synthetic data (offline test)

Outputs (written to results/):
    did_estimates.csv     coefficient table
    event_study.png       pre/post growth path around QT starts
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

sys.path.insert(0, os.path.dirname(__file__))
from data import fetch_fred, make_synthetic  # noqa: E402

RESULTS = os.path.join(os.path.dirname(os.path.dirname(__file__)), "results")


def estimate_did(panel: pd.DataFrame):
    """Difference-in-differences style regression on quarterly growth.

    gdp_growth_t = b0 + b1*QT1_t + b2*QT2_t + b3*COVID_t + b4*lag_growth_t + e_t

    b1 and b2 are the QT-period growth differentials versus baseline quarters.
    HAC (Newey-West) standard errors with 4 lags handle serial correlation.
    """
    d = panel.dropna(subset=["gdp_growth", "gdp_growth_lag"]).copy()
    model = smf.ols(
        "gdp_growth ~ qt1 + qt2 + covid + gdp_growth_lag", data=d
    ).fit(cov_type="HAC", cov_kwds={"maxlags": 4})
    return model


def event_study(panel: pd.DataFrame, start: str, window: int = 6) -> pd.DataFrame:
    """Return growth in the +/- `window` quarters around a QT start date."""
    d = panel.dropna(subset=["gdp_growth"]).copy()
    d = d.reset_index().rename(columns={"index": "date"})
    start_ts = pd.Timestamp(start)
    pos = (d["date"] - start_ts).abs().idxmin()
    lo, hi = max(0, pos - window), min(len(d) - 1, pos + window)
    seg = d.iloc[lo : hi + 1].copy()
    seg["event_time"] = range(lo - pos, hi - pos + 1)
    return seg[["event_time", "gdp_growth"]]


def run(synthetic: bool = False) -> None:
    os.makedirs(RESULTS, exist_ok=True)
    panel = make_synthetic() if synthetic else fetch_fred()

    model = estimate_did(panel)
    table = pd.DataFrame(
        {
            "coef": model.params,
            "std_err": model.bse,
            "t": model.tvalues,
            "p_value": model.pvalues,
            "ci_low": model.conf_int()[0],
            "ci_high": model.conf_int()[1],
        }
    ).round(4)
    table.to_csv(os.path.join(RESULTS, "did_estimates.csv"))

    b1 = model.params.get("qt1", float("nan"))
    b2 = model.params.get("qt2", float("nan"))
    print("\n=== Difference-in-differences estimates (annualized % growth) ===")
    print(table.to_string())
    print(f"\nQT1 growth differential vs baseline: {b1:+.2f} pp")
    print(f"QT2 growth differential vs baseline: {b2:+.2f} pp")
    print(f"QT2 minus QT1 contrast:              {b2 - b1:+.2f} pp")
    print("\nNote: numbers above come from the actual run. Update the resume")
    print("bullet to match whatever this pipeline produces on current data.")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        es1 = event_study(panel, "2017-10-01")
        es2 = event_study(panel, "2022-06-01")
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.axvline(0, color="grey", lw=1, ls="--")
        ax.plot(es1["event_time"], es1["gdp_growth"], marker="o", label="QT1 (2017)")
        ax.plot(es2["event_time"], es2["gdp_growth"], marker="s", label="QT2 (2022)")
        ax.set_xlabel("Quarters relative to QT start")
        ax.set_ylabel("Real GDP growth (annualized %)")
        ax.set_title("Growth path around Fed balance-sheet runoff episodes")
        ax.legend()
        fig.tight_layout()
        fig.savefig(os.path.join(RESULTS, "event_study.png"), dpi=150)
        print(f"\nSaved: {os.path.join(RESULTS, 'event_study.png')}")
    except Exception as exc:  # plotting is optional
        print(f"(Plot skipped: {exc})")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--synthetic", action="store_true", help="run offline on synthetic data")
    args = p.parse_args()
    run(synthetic=args.synthetic)
