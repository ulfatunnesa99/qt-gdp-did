"""
Data layer for the Quantitative Tightening (QT) difference-in-differences study.

Pulls public series from FRED (Federal Reserve Bank of St. Louis) via
pandas_datareader, which does not require an API key. A synthetic generator is
included so the pipeline can be exercised offline and in continuous integration.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# FRED series used in the study.
SERIES = {
    "GDPC1": "real_gdp",        # Real Gross Domestic Product, quarterly, SAAR
    "WALCL": "fed_assets",      # Fed total assets (balance sheet), weekly
    "FEDFUNDS": "fed_funds",    # Effective federal funds rate, monthly
    "UNRATE": "unemployment",   # Unemployment rate, monthly
    "CPIAUCSL": "cpi",          # CPI, all urban consumers, monthly
}

START = "2008-01-01"
END = "2025-01-01"


def fetch_fred(start: str = START, end: str = END) -> pd.DataFrame:
    """Fetch and resample the study series to a quarterly panel.

    Returns a quarterly DataFrame indexed by period end, with real GDP growth
    (annualized log change) as the outcome plus control levels/changes.
    """
    from pandas_datareader import data as pdr  # imported lazily so offline use works

    raw = {}
    for code, name in SERIES.items():
        raw[name] = pdr.DataReader(code, "fred", start, end)[code]

    # Resample everything to quarter end.
    q = pd.DataFrame(index=pd.date_range(start, end, freq="QE"))
    q["real_gdp"] = raw["real_gdp"].resample("QE").last()
    q["fed_assets"] = raw["fed_assets"].resample("QE").last()
    q["fed_funds"] = raw["fed_funds"].resample("QE").mean()
    q["unemployment"] = raw["unemployment"].resample("QE").mean()
    q["cpi"] = raw["cpi"].resample("QE").last()

    return _engineer(q.dropna(how="all"))


def make_synthetic(n_quarters: int = 68, seed: int = 42) -> pd.DataFrame:
    """Generate a synthetic quarterly panel with the same columns as fetch_fred.

    Used only for offline testing of the estimation code. Not for analysis.
    """
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2008-03-31", periods=n_quarters, freq="QE")
    gdp = 15000 * np.cumprod(1 + rng.normal(0.005, 0.006, n_quarters))
    df = pd.DataFrame(index=idx)
    df["real_gdp"] = gdp
    df["fed_assets"] = 800 + np.cumsum(rng.normal(30, 15, n_quarters))
    df["fed_funds"] = np.clip(np.cumsum(rng.normal(0, 0.15, n_quarters)), 0, 6)
    df["unemployment"] = np.clip(5 + np.cumsum(rng.normal(0, 0.2, n_quarters)), 3, 12)
    df["cpi"] = 210 * np.cumprod(1 + rng.normal(0.005, 0.003, n_quarters))
    return _engineer(df)


def _engineer(q: pd.DataFrame) -> pd.DataFrame:
    """Build outcome and regressors shared by real and synthetic paths."""
    q = q.copy()
    # Annualized quarterly real GDP growth, in percent.
    q["gdp_growth"] = np.log(q["real_gdp"]).diff() * 400.0
    q["gdp_growth_lag"] = q["gdp_growth"].shift(1)
    q["cpi_infl"] = np.log(q["cpi"]).diff() * 400.0

    # COVID shock control: 2020Q1-Q2 are extreme outliers unrelated to QT.
    q["covid"] = ((q.index >= "2020-01-01") & (q.index <= "2020-06-30")).astype(int)

    # Treatment windows (Fed balance-sheet runoff episodes).
    # QT1: Oct 2017 - Aug 2019.  QT2: Jun 2022 - end of sample.
    q["qt1"] = ((q.index >= "2017-10-01") & (q.index <= "2019-09-30")).astype(int)
    q["qt2"] = (q.index >= "2022-04-01").astype(int)
    return q
